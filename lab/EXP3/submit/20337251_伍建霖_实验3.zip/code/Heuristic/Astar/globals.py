"""
Variables used for memory comparison.
HEURISTIC is used to determine which heuristic to use: Manhattan Distance or Misplaced Tiles.
"""

memory_main = 0
memory_bfs = 0
memory_iddfs = 0
memory_nr_iddfs = 0
memory_manhattan_astar = 0
memory_displaced_astar = 0
HEURISTIC = ''
